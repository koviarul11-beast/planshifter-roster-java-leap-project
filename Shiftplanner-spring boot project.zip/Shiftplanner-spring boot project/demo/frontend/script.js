const API_BASE = "/api";
const state = {
	employees: [],
	rosters: [],
	roster: null,
	swaps: [],
	weekStart: mondayOf(new Date()),
	activeView: "roster",
	requestFilter: "all",
	editingEmployeeId: null,
	editingRosterId: null,
	editingShiftId: null,
	editingSwapId: null,
	editingSwapRosterId: null,
	noticeTimer: null
};

const $ = (selector, root = document) => root.querySelector(selector);
const $$ = (selector, root = document) => [...root.querySelectorAll(selector)];

function mondayOf(date) {
	const monday = new Date(date.getFullYear(), date.getMonth(), date.getDate());
	const daysSinceMonday = (monday.getDay() + 6) % 7;
	monday.setDate(monday.getDate() - daysSinceMonday);
	return monday;
}

function addDays(date, days) {
	const result = new Date(date.getFullYear(), date.getMonth(), date.getDate());
	result.setDate(result.getDate() + days);
	return result;
}

function dateKey(date) {
	const year = date.getFullYear();
	const month = String(date.getMonth() + 1).padStart(2, "0");
	const day = String(date.getDate()).padStart(2, "0");
	return `${year}-${month}-${day}`;
}

function escapeHtml(value = "") {
	return String(value).replace(/[&<>"']/g, (character) => ({
		"&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;"
	})[character]);
}

function initials(name = "") {
	return name.trim().split(/\s+/).slice(0, 2).map((part) => part[0] || "").join("").toUpperCase() || "?";
}

function formatTime(value) {
	if (!value) return "—";
	const [hour, minute] = value.slice(11, 16).split(":").map(Number);
	const date = new Date(2000, 0, 1, hour, minute);
	return new Intl.DateTimeFormat(undefined, { hour: "numeric", minute: "2-digit" }).format(date);
}

function formatShortDate(value) {
	if (!value) return "Date unavailable";
	const [year, month, day] = value.slice(0, 10).split("-").map(Number);
	return new Intl.DateTimeFormat(undefined, { weekday: "short", month: "short", day: "numeric" })
		.format(new Date(year, month - 1, day));
}

function formatWeek(start) {
	const end = addDays(start, 6);
	const monthDay = { month: "short", day: "numeric" };
	const left = new Intl.DateTimeFormat(undefined, monthDay).format(start);
	const right = new Intl.DateTimeFormat(undefined, { ...monthDay, year: "numeric" }).format(end);
	return `${left} – ${right}`;
}

async function api(path, options = {}) {
	const response = await fetch(`${API_BASE}${path}`, {
		...options,
		headers: { "Content-Type": "application/json", ...(options.headers || {}) }
	});
	const text = await response.text();
	let body = null;
	if (text) {
		try { body = JSON.parse(text); } catch { body = text; }
	}
	if (!response.ok) {
		throw new Error(body?.message || body?.detail || `Request failed (${response.status}).`);
	}
	return body;
}

function setConnection(online) {
	const dot = $("#connection-dot");
	dot.classList.toggle("is-online", online);
	dot.classList.toggle("is-offline", !online);
	$("#connection-label").textContent = online ? "Roster connected" : "API unavailable";
}

function showNotice(message, type = "success") {
	const notice = $("#notice");
	window.clearTimeout(state.noticeTimer);
	notice.textContent = message;
	notice.className = `notice${type === "error" ? " is-error" : type === "info" ? " is-info" : ""}`;
	notice.hidden = false;
	state.noticeTimer = window.setTimeout(() => { notice.hidden = true; }, type === "error" ? 6500 : 3800);
}

function currentActor() {
	const id = Number($("#actor-select").value);
	return state.employees.find((employee) => employee.id === id) || null;
}

function currentShifts() {
	return state.roster?.shifts || [];
}

function updateActorOptions() {
	const select = $("#actor-select");
	const previous = select.value;
	select.innerHTML = state.employees.length
		? state.employees.map((employee) => `<option value="${employee.id}">${escapeHtml(employee.name)}${employee.manager ? " · Manager" : ""}</option>`).join("")
		: `<option value="">No employees yet</option>`;
	const stillExists = state.employees.some((employee) => String(employee.id) === previous);
	const preferred = state.employees.find((employee) => employee.manager) || state.employees[0];
	select.value = stillExists ? previous : preferred ? String(preferred.id) : "";
}

async function loadSwaps() {
	if (!state.employees.length) {
		state.swaps = [];
		return;
	}
	const results = await Promise.allSettled(state.employees.map((employee) =>
		api(`/swaps?employeeId=${encodeURIComponent(employee.id)}`)));
	const swapsById = new Map();
	results.forEach((result) => {
		if (result.status === "fulfilled" && Array.isArray(result.value)) {
			result.value.forEach((swap) => swapsById.set(swap.id, swap));
		}
	});
	state.swaps = [...swapsById.values()].sort((first, second) =>
		new Date(second.requestedAt || 0) - new Date(first.requestedAt || 0));
}

async function reloadData() {
	try {
		const [employees, rosters] = await Promise.all([api("/employees"), api("/rosters")]);
		state.employees = Array.isArray(employees) ? employees : [];
		state.rosters = Array.isArray(rosters) ? rosters : [];
		state.roster = state.rosters.find((roster) => roster.weekStartDate === dateKey(state.weekStart)) || null;
		updateActorOptions();
		await loadSwaps();
		setConnection(true);
		renderAll();
	} catch (error) {
		setConnection(false);
		renderAll();
		showNotice(`Couldn't load the roster API. ${error.message}`, "error");
	}
}

function renderWeekHeading() {
	$("#week-label").textContent = formatWeek(state.weekStart);
	$("#footer-week").textContent = `WEEK OF ${dateKey(state.weekStart)}`;
}

function renderMetrics() {
	const shifts = currentShifts();
	const scheduledIds = new Set(shifts.map((shift) => shift.employee?.id).filter(Boolean));
	const pending = state.swaps.filter((swap) => ["PENDING_COLLEAGUE", "PENDING_MANAGER"].includes(swap.status));
	$("#metric-shifts").textContent = shifts.length;
	$("#metric-shifts-foot").textContent = state.roster ? "Scheduled assignments" : "No roster for this week";
	$("#metric-people").textContent = scheduledIds.size;
	$("#metric-people-foot").textContent = "People with at least one shift";
	$("#metric-pending").textContent = pending.length;
	$("#metric-pending-foot").textContent = pending.length === 1 ? "Request in progress" : "Requests in progress";
	$("#metric-team").textContent = state.employees.length;
	$("#metric-team-foot").textContent = "Employees in the directory";
	$("#nav-pending-count").textContent = pending.length;
	$("#request-heading-count").textContent = state.swaps.length;
}

function renderCalendar() {
	const empty = !state.roster;
	$("#roster-empty").hidden = !empty;
	$("#calendar-scroll").hidden = empty;
	$(".roster-legend").hidden = empty;
	$("#roster-record-actions").hidden = empty;
	$("#add-shift-button").disabled = empty;
	if (empty) return;

	const today = dateKey(new Date());
	const swapByShift = new Map();
	const swapHistoryIds = new Set();
	state.swaps.forEach((swap) => {
		if (swap.requestedShift?.id) swapHistoryIds.add(swap.requestedShift.id);
		if (swap.offeredShift?.id) swapHistoryIds.add(swap.offeredShift.id);
	});
	state.swaps.filter((swap) => ["PENDING_COLLEAGUE", "PENDING_MANAGER"].includes(swap.status))
		.forEach((swap) => {
			swapByShift.set(swap.requestedShift?.id, swap);
			swapByShift.set(swap.offeredShift?.id, swap);
		});

	$("#calendar-grid").innerHTML = Array.from({ length: 7 }, (_, index) => {
		const date = addDays(state.weekStart, index);
		const key = dateKey(date);
		const dayShifts = currentShifts().filter((shift) => shift.startsAt?.slice(0, 10) === key)
			.sort((left, right) => left.startsAt.localeCompare(right.startsAt));
		const dayName = new Intl.DateTimeFormat(undefined, { weekday: "short" }).format(date).toUpperCase();
		const cards = dayShifts.length ? dayShifts.map((shift) => {
			const pendingSwap = swapByShift.get(shift.id);
			const hasSwapHistory = swapHistoryIds.has(shift.id);
			const employee = shift.employee || {};
			return `<article class="shift-card${pendingSwap ? " is-pending" : ""}">
				<div class="shift-card-actions">
					<button class="shift-action" data-shift-edit="${shift.id}" type="button" aria-label="Edit shift" title="${hasSwapHistory ? "Shifts in swap history cannot be changed" : "Edit shift"}"${hasSwapHistory ? " disabled" : ""}><svg viewBox="0 0 24 24" aria-hidden="true"><path d="m14 5 5 5M4 20l4.2-.8L19 8.4 15.6 5 4.8 15.8 4 20z"/></svg></button>
					<button class="shift-action is-delete" data-shift-delete="${shift.id}" type="button" aria-label="Delete shift" title="${hasSwapHistory ? "Shifts in swap history cannot be deleted" : "Delete shift"}"${hasSwapHistory ? " disabled" : ""}><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 7h16M10 11v6m4-6v6M6 7l1 14h10l1-14M9 7V4h6v3"/></svg></button>
				</div>
				<div class="shift-time">${formatTime(shift.startsAt)} – ${formatTime(shift.endsAt)}</div>
				<div class="shift-employee" title="${escapeHtml(employee.name || "Unassigned")}">${escapeHtml(employee.name || "Unassigned")}</div>
				<div class="shift-role">${employee.manager ? "Manager" : "Team member"}</div>
				${pendingSwap ? `<span class="shift-pending-label">SWAP IN REVIEW</span>` : ""}
			</article>`;
		}).join("") : `<div class="day-empty">NO SHIFTS</div>`;
		return `<section class="day-column${key === today ? " is-today" : ""}" aria-label="${dayName}, ${key}">
			<header class="day-head"><div><div class="day-name">${dayName}</div><div class="day-number">${date.getDate()}</div></div><span class="day-shift-count">${dayShifts.length || ""}</span></header>
			<div class="day-body">${cards}</div>
		</section>`;
	}).join("");
}

function statusLabel(status) {
	return ({
		PENDING_COLLEAGUE: "Awaiting colleague",
		PENDING_MANAGER: "Awaiting manager",
		APPROVED: "Approved",
		DECLINED: "Declined"
	})[status] || status;
}

function shiftSummary(shift) {
	return `${formatShortDate(shift?.startsAt)} · ${formatTime(shift?.startsAt)}–${formatTime(shift?.endsAt)}`;
}

function decisionMarkup(swap) {
	const actor = currentActor();
	if (!actor) return "";
	if (swap.status === "PENDING_COLLEAGUE" && actor.id === swap.colleague?.id) {
		return `<div class="decision-actions"><button class="decision-button" data-decision="DECLINE" data-swap-id="${swap.id}" type="button">Decline</button><button class="decision-button is-approve" data-decision="ACCEPT" data-swap-id="${swap.id}" type="button">Accept</button></div>`;
	}
	if (swap.status === "PENDING_MANAGER" && actor.manager) {
		return `<div class="decision-actions"><button class="decision-button" data-decision="DECLINE" data-swap-id="${swap.id}" type="button">Decline</button><button class="decision-button is-approve" data-decision="APPROVE" data-swap-id="${swap.id}" type="button">Approve</button></div>`;
	}
	return "";
}

function renderRequests() {
	const filtered = state.swaps.filter((swap) => {
		const active = ["PENDING_COLLEAGUE", "PENDING_MANAGER"].includes(swap.status);
		return state.requestFilter === "all" || (state.requestFilter === "active" ? active : !active);
	});
	if (!filtered.length) {
		const message = state.requestFilter === "all" && !state.swaps.length
			? ["No swap requests yet", "Requests will appear here after an employee proposes an exchange."]
			: ["Nothing in this view", "Try another filter to find a request."];
		$("#request-list").innerHTML = `<div class="empty-list"><strong>${message[0]}</strong><span>${message[1]}</span></div>`;
		return;
	}
	$("#request-list").innerHTML = filtered.map((swap, index) => {
		const requester = swap.requester || {};
		const colleague = swap.colleague || {};
		const statusClass = swap.status === "APPROVED" ? " is-approved" : swap.status === "DECLINED" ? " is-declined" : "";
		const canManage = swap.status === "PENDING_COLLEAGUE";
		return `<article class="request-card" style="animation-delay:${Math.min(index * 35, 175)}ms">
			<div class="request-person">
				<span class="avatar">${escapeHtml(initials(requester.name))}</span>
				<div class="request-person-copy"><strong>${escapeHtml(requester.name || "Employee")}</strong><span>requests a swap with ${escapeHtml(colleague.name || "colleague")}</span></div>
				<span class="swap-arrows" aria-hidden="true"><svg viewBox="0 0 24 24"><path d="M5 8h13l-3-3m3 3-3 3M19 16H6l3 3m-3-3 3-3"/></svg></span>
				<span class="avatar avatar-coral">${escapeHtml(initials(colleague.name))}</span>
			</div>
			<div class="request-shifts">
				<div class="request-shift"><small>REQUESTER'S SHIFT</small><strong>${escapeHtml(requester.name || "Requester")}</strong><span>${escapeHtml(shiftSummary(swap.requestedShift))}</span></div>
				<span class="request-arrow">⇄</span>
				<div class="request-shift"><small>COLLEAGUE'S SHIFT</small><strong>${escapeHtml(colleague.name || "Colleague")}</strong><span>${escapeHtml(shiftSummary(swap.offeredShift))}</span></div>
			</div>
			<div class="request-actions"><span class="status-badge${statusClass}">${escapeHtml(statusLabel(swap.status))}</span><div class="request-controls"><div class="request-management"><button class="record-action" data-swap-edit="${swap.id}" type="button" aria-label="Edit swap request ${swap.id}" title="${canManage ? "Edit swap request" : "Only editable before colleague acceptance"}"${canManage ? "" : " disabled"}><svg viewBox="0 0 24 24" aria-hidden="true"><path d="m14 5 5 5M4 20l4.2-.8L19 8.4 15.6 5 4.8 15.8 4 20z"/></svg></button><button class="record-action is-delete" data-swap-delete="${swap.id}" type="button" aria-label="Delete swap request ${swap.id}" title="${canManage ? "Delete swap request" : "Only deletable before colleague acceptance"}"${canManage ? "" : " disabled"}><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 7h16M10 11v6m4-6v6M6 7l1 14h10l1-14M9 7V4h6v3"/></svg></button></div>${decisionMarkup(swap)}</div></div>
		</article>`;
	}).join("");
}

function renderTeam() {
	const tbody = $("#team-table-body");
	$("#team-empty").hidden = state.employees.length > 0;
	tbody.innerHTML = state.employees.map((employee) => {
		const count = currentShifts().filter((shift) => shift.employee?.id === employee.id).length;
		return `<tr>
			<td class="team-id">${employee.id}</td>
			<td class="team-member-cell"><span class="avatar">${escapeHtml(initials(employee.name))}</span>${escapeHtml(employee.name)}</td>
			<td><span class="role-badge${employee.manager ? " is-manager" : ""}">${employee.manager ? "Manager" : "Team member"}</span></td>
			<td><span class="team-shift-count">${count}</span></td>
			<td class="team-email">${escapeHtml(employee.email)}</td>
			<td><div class="table-actions"><button class="record-action" data-employee-edit="${employee.id}" type="button" aria-label="Edit ${escapeHtml(employee.name)}" title="Edit employee"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="m14 5 5 5M4 20l4.2-.8L19 8.4 15.6 5 4.8 15.8 4 20z"/></svg></button><button class="record-action is-delete" data-employee-delete="${employee.id}" type="button" aria-label="Delete ${escapeHtml(employee.name)}" title="Delete employee"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 7h16M10 11v6m4-6v6M6 7l1 14h10l1-14M9 7V4h6v3"/></svg></button></div></td>
		</tr>`;
	}).join("");
}

function renderAll() {
	renderWeekHeading();
	renderMetrics();
	renderCalendar();
	renderRequests();
	renderTeam();
}

function setView(view) {
	state.activeView = view;
	const labels = { roster: "WEEKLY ROSTER", requests: "SWAP REQUESTS", team: "TEAM DIRECTORY" };
	const headings = {
		roster: ["PLAN · REVIEW · ADJUST", "Weekly roster", "A clear view of who's on, and when."],
		requests: ["KEEP EVERY HANDOFF VISIBLE", "Swap requests", "Every exchange, through colleague and manager approval."],
		team: ["YOUR PEOPLE, ONE PLACE", "Team directory", "The people who keep the operation moving."]
	};
	$$(".nav-link").forEach((button) => button.classList.toggle("is-active", button.dataset.view === view));
	$$(".view-panel").forEach((panel) => {
		const active = panel.id === `view-${view}`;
		panel.classList.toggle("is-visible", active);
		panel.hidden = !active;
	});
	$("#topbar-view").textContent = labels[view];
	$("#page-eyebrow").textContent = headings[view][0];
	$("#page-title").textContent = headings[view][1];
	$("#page-subtitle").textContent = headings[view][2];
	$("#week-label").closest(".week-controls").hidden = view !== "roster";
	$("#add-shift-button").hidden = view !== "roster";
	$("#add-employee-button").hidden = view === "team";
}

function fillSelect(select, options, placeholder) {
	select.innerHTML = `<option value="">${escapeHtml(placeholder)}</option>${options.map((option) =>
		`<option value="${option.value}">${escapeHtml(option.label)}</option>`).join("")}`;
}

function shiftsForEmployee(employeeId, roster = state.roster) {
	return (roster?.shifts || []).filter((shift) => shift.employee?.id === Number(employeeId));
}

function shiftOption(shift) {
	return { value: shift.id, label: `${formatShortDate(shift.startsAt)} · ${formatTime(shift.startsAt)}–${formatTime(shift.endsAt)}` };
}

function updateSwapOptions() {
	const roster = state.rosters.find((item) => item.id === state.editingSwapRosterId) || state.roster || state.rosters[0] || null;
	const requesterSelect = $("#swap-requester");
	const requestedSelect = $("#swap-requested-shift");
	const colleagueSelect = $("#swap-colleague");
	const offeredSelect = $("#swap-offered-shift");
	const requesterId = requesterSelect.value;
	const requestedCurrent = requestedSelect.value;
	const colleagueCurrent = colleagueSelect.value;
	const offeredCurrent = offeredSelect.value;
	fillSelect(requestedSelect, shiftsForEmployee(requesterId, roster).map(shiftOption), "Choose their shift");
	if ([...requestedSelect.options].some((option) => option.value === requestedCurrent)) requestedSelect.value = requestedCurrent;

	const eligibleColleagues = state.employees.filter((employee) => employee.id !== Number(requesterId)
		&& shiftsForEmployee(employee.id, roster).length > 0);
	fillSelect(colleagueSelect, eligibleColleagues.map((employee) => ({ value: employee.id, label: employee.name })), "Choose a colleague");
	if (eligibleColleagues.some((employee) => String(employee.id) === colleagueCurrent)) colleagueSelect.value = colleagueCurrent;
	fillSelect(offeredSelect, shiftsForEmployee(colleagueSelect.value, roster).map(shiftOption), "Choose their shift");
	if ([...offeredSelect.options].some((option) => option.value === offeredCurrent)) offeredSelect.value = offeredCurrent;
}

function openEmployeeDialog(employee = null) {
	const form = $("#employee-form");
	form.reset();
	state.editingEmployeeId = employee?.id ?? null;
	$("#employee-dialog-title").textContent = employee ? "Edit employee" : "Add an employee";
	$("#employee-submit").textContent = employee ? "Save changes" : "Add to team";
	if (employee) {
		form.elements.namedItem("name").value = employee.name;
		form.elements.namedItem("email").value = employee.email;
		form.elements.namedItem("manager").checked = employee.manager;
	}
	$("#employee-dialog").showModal();
}

async function deleteEmployee(employeeId) {
	const employee = state.employees.find((item) => item.id === Number(employeeId));
	if (!employee || !window.confirm(`Delete ${employee.name} from the team?`)) return;
	try {
		await api(`/employees/${employeeId}`, { method: "DELETE" });
		await reloadData();
		showNotice("Employee deleted from the team.");
	} catch (error) { showNotice(error.message, "error"); }
}

async function openShiftDialog() {
	if (!state.roster) {
		try {
			showNotice("Creating the roster for this week...", "info");
			await createRoster();
		} catch (error) {
			showNotice(error.message, "error");
			return;
		}
		if (!state.roster) {
			showNotice("The roster could not be created. Try again.", "error");
			return;
		}
	}
	if (!state.employees.length) {
		showNotice("Add an employee before requesting a shift.", "info");
		return;
	}
	const form = $("#shift-form");
	form.reset();
	state.editingShiftId = null;
	$("#shift-dialog-title").textContent = "Request shift";
	$("#shift-submit").textContent = "Save shift request";
	fillSelect($("#shift-employee"), state.employees.map((employee) => ({ value: employee.id, label: employee.name })), "Choose an employee");
	$("#shift-date").min = dateKey(state.weekStart);
	$("#shift-date").max = dateKey(addDays(state.weekStart, 6));
	$("#shift-date").value = dateKey(state.weekStart);
	$("#shift-dialog").showModal();
}

function openEditShiftDialog(shiftId) {
	const shift = currentShifts().find((item) => item.id === Number(shiftId));
	if (!shift) return;
	const form = $("#shift-form");
	form.reset();
	state.editingShiftId = shift.id;
	$("#shift-dialog-title").textContent = "Edit shift";
	$("#shift-submit").textContent = "Save changes";
	fillSelect($("#shift-employee"), state.employees.map((employee) => ({ value: employee.id, label: employee.name })), "Choose an employee");
	$("#shift-date").min = dateKey(state.weekStart);
	$("#shift-date").max = dateKey(addDays(state.weekStart, 6));
	$("#shift-employee").value = String(shift.employee.id);
	$("#shift-date").value = shift.startsAt.slice(0, 10);
	$("#shift-form [name=startsAt]").value = shift.startsAt.slice(11, 16);
	$("#shift-form [name=endsAt]").value = shift.endsAt.slice(11, 16);
	$("#shift-dialog").showModal();
}

async function deleteShift(shiftId) {
	if (!window.confirm("Delete this shift from the roster?")) return;
	try {
		await api(`/rosters/${state.roster.id}/shifts/${shiftId}`, { method: "DELETE" });
		await reloadData();
		showNotice("Shift deleted from the roster.");
	} catch (error) { showNotice(error.message, "error"); }
}

function openSwapDialog(swap = null) {
	if (!state.employees.length) {
		showNotice("Add employees before creating a shift request.", "info");
		return;
	}
	const roster = swap
		? state.rosters.find((item) => item.shifts?.some((shift) => shift.id === swap.requestedShift?.id))
		: state.rosters.find((item) => (item.shifts || []).length > 0) || state.roster || state.rosters[0] || null;
	const form = $("#swap-form");
	form.reset();
	state.editingSwapId = swap?.id ?? null;
	state.editingSwapRosterId = roster?.id ?? null;
	$("#swap-dialog-title").textContent = swap ? "Edit shift request" : "Request shift";
	$("#swap-submit").textContent = swap ? "Save changes" : "Send request";
	const eligibleRequesters = state.employees.filter((employee) => {
		if (!roster) return false;
		return shiftsForEmployee(employee.id, roster).length > 0;
	});
	fillSelect($("#swap-requester"), eligibleRequesters.map((employee) => ({ value: employee.id, label: employee.name })), "Choose an employee");
	const actor = currentActor();
	if (swap) $("#swap-requester").value = String(swap.requester.id);
	else if (actor && roster && shiftsForEmployee(actor.id, roster).length) $("#swap-requester").value = String(actor.id);
	updateSwapOptions();
	if (swap) {
		$("#swap-requested-shift").value = String(swap.requestedShift.id);
		$("#swap-colleague").value = String(swap.colleague.id);
		updateSwapOptions();
		$("#swap-offered-shift").value = String(swap.offeredShift.id);
	}
	$("#swap-dialog").showModal();
}

async function deleteSwap(swapId) {
	if (!window.confirm("Delete this swap request?")) return;
	try {
		await api(`/swaps/${swapId}`, { method: "DELETE" });
		await reloadData();
		showNotice("Swap request deleted.");
	} catch (error) { showNotice(error.message, "error"); }
}

async function createRoster() {
	try {
		await api("/rosters", { method: "POST", body: JSON.stringify({ weekStartDate: dateKey(state.weekStart) }) });
		await reloadData();
		showNotice("Roster created. Add shifts to build the week.");
	} catch (error) {
		showNotice(error.message, "error");
	}
}

function openRosterDialog() {
	if (!state.roster) return;
	state.editingRosterId = state.roster.id;
	$("#roster-week-start").value = state.roster.weekStartDate;
	$("#roster-dialog").showModal();
}

async function deleteRoster() {
	if (!state.roster || !window.confirm(`Delete the roster for ${formatWeek(state.weekStart)} and all its shifts?`)) return;
	try {
		await api(`/rosters/${state.roster.id}`, { method: "DELETE" });
		await reloadData();
		showNotice("Weekly roster deleted.");
	} catch (error) { showNotice(error.message, "error"); }
}

function bindEvents() {
	$$(".nav-link").forEach((button) => button.addEventListener("click", () => setView(button.dataset.view)));
	$("#previous-week").addEventListener("click", () => { state.weekStart = addDays(state.weekStart, -7); reloadData(); });
	$("#next-week").addEventListener("click", () => { state.weekStart = addDays(state.weekStart, 7); reloadData(); });
	$("#this-week-button").addEventListener("click", () => { state.weekStart = mondayOf(new Date()); reloadData(); });
	$("#week-label").addEventListener("click", () => { state.weekStart = mondayOf(new Date()); reloadData(); });
	$("#actor-select").addEventListener("change", renderRequests);
	$("#add-employee-button").addEventListener("click", openEmployeeDialog);
	$("#team-add-button").addEventListener("click", openEmployeeDialog);
	$("#team-empty-add").addEventListener("click", openEmployeeDialog);
	$("#request-swap-button").addEventListener("click", () => openSwapDialog());
	$("#add-shift-button").addEventListener("click", openShiftDialog);
	$("#create-roster-button").addEventListener("click", createRoster);
	$("#edit-roster-button").addEventListener("click", openRosterDialog);
	$("#delete-roster-button").addEventListener("click", deleteRoster);
	$("#team-table-body").addEventListener("click", (event) => {
		const editButton = event.target.closest("[data-employee-edit]");
		const deleteButton = event.target.closest("[data-employee-delete]");
		if (editButton) openEmployeeDialog(state.employees.find((employee) => employee.id === Number(editButton.dataset.employeeEdit)));
		if (deleteButton) deleteEmployee(deleteButton.dataset.employeeDelete);
	});
	$("#calendar-grid").addEventListener("click", (event) => {
		const editButton = event.target.closest("[data-shift-edit]");
		const deleteButton = event.target.closest("[data-shift-delete]");
		if (editButton && !editButton.disabled) openEditShiftDialog(editButton.dataset.shiftEdit);
		if (deleteButton && !deleteButton.disabled) deleteShift(deleteButton.dataset.shiftDelete);
	});
	$("#swap-requester").addEventListener("change", updateSwapOptions);
	$("#swap-colleague").addEventListener("change", updateSwapOptions);
	$$("[data-close-dialog]").forEach((button) => button.addEventListener("click", () => button.closest("dialog").close()));
	$$("[data-request-filter]").forEach((button) => button.addEventListener("click", () => {
		state.requestFilter = button.dataset.requestFilter;
		$$("[data-request-filter]").forEach((filter) => filter.classList.toggle("is-selected", filter === button));
		renderRequests();
	}));

	$("#employee-form").addEventListener("submit", async (event) => {
		event.preventDefault();
		const form = new FormData(event.currentTarget);
		try {
			await api(`/employees${state.editingEmployeeId !== null ? `/${state.editingEmployeeId}` : ""}`, { method: state.editingEmployeeId !== null ? "PUT" : "POST", body: JSON.stringify({
				name: form.get("name").trim(), email: form.get("email").trim(), manager: form.has("manager")
			}) });
			$("#employee-dialog").close();
			const wasEditing = state.editingEmployeeId !== null;
			state.editingEmployeeId = null;
			await reloadData();
			showNotice(wasEditing ? "Employee updated." : "Employee added to the team.");
		} catch (error) { showNotice(error.message, "error"); }
	});

	$("#roster-form").addEventListener("submit", async (event) => {
		event.preventDefault();
		const weekStartDate = new FormData(event.currentTarget).get("weekStartDate");
		if (new Date(`${weekStartDate}T00:00:00`).getDay() !== 1) {
			showNotice("A roster week must start on Monday.", "error");
			return;
		}
		try {
			await api(`/rosters/${state.editingRosterId}`, { method: "PUT", body: JSON.stringify({ weekStartDate }) });
			state.weekStart = mondayOf(new Date(`${weekStartDate}T00:00:00`));
			state.editingRosterId = null;
			$("#roster-dialog").close();
			await reloadData();
			showNotice("Weekly roster updated.");
		} catch (error) { showNotice(error.message, "error"); }
	});

	$("#shift-form").addEventListener("submit", async (event) => {
		event.preventDefault();
		const form = new FormData(event.currentTarget);
		const date = form.get("date");
		try {
			await api(`/rosters/${state.roster.id}/shifts${state.editingShiftId ? `/${state.editingShiftId}` : ""}`, { method: state.editingShiftId ? "PUT" : "POST", body: JSON.stringify({
				employeeId: Number(form.get("employeeId")),
				startsAt: `${date}T${form.get("startsAt")}:00`,
				endsAt: `${date}T${form.get("endsAt")}:00`
			}) });
			$("#shift-dialog").close();
			const wasEditing = Boolean(state.editingShiftId);
			state.editingShiftId = null;
			await reloadData();
			showNotice(wasEditing ? "Shift updated." : "Shift added to the roster.");
		} catch (error) { showNotice(error.message, "error"); }
	});

	$("#swap-form").addEventListener("submit", async (event) => {
		event.preventDefault();
		const form = new FormData(event.currentTarget);
		const wasEditing = state.editingSwapId !== null;
		try {
			await api(`/swaps${wasEditing ? `/${state.editingSwapId}` : ""}`, { method: wasEditing ? "PUT" : "POST", body: JSON.stringify({
				requesterId: Number(form.get("requesterId")),
				colleagueId: Number(form.get("colleagueId")),
				requestedShiftId: Number(form.get("requestedShiftId")),
				offeredShiftId: Number(form.get("offeredShiftId"))
			}) });
			$("#swap-dialog").close();
			state.editingSwapId = null;
			state.editingSwapRosterId = null;
			await reloadData();
			if (!wasEditing) setView("requests");
			showNotice(wasEditing ? "Swap request updated." : "Swap request sent to the colleague.");
		} catch (error) { showNotice(error.message, "error"); }
	});

	$("#request-list").addEventListener("click", async (event) => {
		const editSwapButton = event.target.closest("[data-swap-edit]");
		const deleteSwapButton = event.target.closest("[data-swap-delete]");
		if (editSwapButton && !editSwapButton.disabled) {
			const swap = state.swaps.find((item) => item.id === Number(editSwapButton.dataset.swapEdit));
			if (swap) openSwapDialog(swap);
			return;
		}
		if (deleteSwapButton && !deleteSwapButton.disabled) {
			await deleteSwap(deleteSwapButton.dataset.swapDelete);
			return;
		}
		const button = event.target.closest("[data-decision]");
		if (!button) return;
		const actor = currentActor();
		if (!actor) return showNotice("Choose an employee before responding.", "error");
		const colleagueAction = button.dataset.decision === "ACCEPT" ||
			state.swaps.find((swap) => swap.id === Number(button.dataset.swapId))?.status === "PENDING_COLLEAGUE";
		const suffix = colleagueAction ? "colleague-decision" : "manager-decision";
		button.disabled = true;
		try {
			await api(`/swaps/${button.dataset.swapId}/${suffix}`, { method: "PUT", body: JSON.stringify({
				actorId: actor.id, decision: button.dataset.decision
			}) });
			await reloadData();
			showNotice(button.dataset.decision === "DECLINE" ? "Swap request declined." : "Swap request updated.");
		} catch (error) { button.disabled = false; showNotice(error.message, "error"); }
	});
}

bindEvents();
setView("roster");
renderWeekHeading();
reloadData();
