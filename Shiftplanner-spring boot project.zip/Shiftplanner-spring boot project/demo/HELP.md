# Getting Started

## Shift Planner API

Configure MySQL in `src/main/resources/application.properties`, then run the application:

```powershell
.\mvnw.cmd spring-boot:run
```

The dashboard is at `http://localhost:8080/`. Swagger UI remains available at `http://localhost:8080/swagger-ui.html` for exploring and testing the REST API under `http://localhost:8080/api`.

Create employees with `POST /employees`:

```json
{"name":"Ava","email":"ava@example.com","manager":false}
```

Create a Monday-starting weekly roster with `POST /rosters`, then assign shifts using `POST /rosters/{rosterId}/shifts`:

```json
{"weekStartDate":"2026-09-28"}
```

```json
{"employeeId":1,"startsAt":"2026-09-28T09:00:00","endsAt":"2026-09-28T17:00:00"}
```

Request an exchange with `POST /swaps`. Both shift IDs must belong to the same roster and to the two named employees:

```json
{"requesterId":1,"colleagueId":2,"requestedShiftId":1,"offeredShiftId":2}
```

The colleague responds at `PUT /swaps/{id}/colleague-decision` with `{"actorId":2,"decision":"ACCEPT"}` or `"DECLINE"`. An accepted request remains unapplied until a manager calls `PUT /swaps/{id}/manager-decision` with `{"actorId":3,"decision":"APPROVE"}` or `"DECLINE"`. A manager is an employee created with `"manager":true`.

Use `GET /rosters` or `GET /rosters/{id}` to view current assignments, and `GET /swaps?employeeId={id}` to view an employee's swap requests. Overlapping shifts are rejected, and overlap is checked again immediately before manager approval is applied. Invalid requests return a JSON error with an HTTP 4xx status.

Run tests with:

```powershell
.\mvnw.cmd test
```

### Reference Documentation
For further reference, please consider the following sections:

* [Official Apache Maven documentation](https://maven.apache.org/guides/index.html)
* [Spring Boot Maven Plugin Reference Guide](https://docs.spring.io/spring-boot/4.1.1/maven-plugin)
* [Create an OCI image](https://docs.spring.io/spring-boot/4.1.1/maven-plugin/build-image.html)
* [Spring Web](https://docs.spring.io/spring-boot/4.1.1/reference/web/servlet.html)
* [Spring Data JPA](https://docs.spring.io/spring-boot/4.1.1/reference/data/sql.html#data.sql.jpa-and-spring-data)
* [Spring Data JDBC](https://docs.spring.io/spring-boot/4.1.1/reference/data/sql.html#data.sql.jdbc)

### Guides
The following guides illustrate how to use some features concretely:

* [Building a RESTful Web Service](https://spring.io/guides/gs/rest-service/)
* [Serving Web Content with Spring MVC](https://spring.io/guides/gs/serving-web-content/)
* [Building REST services with Spring](https://spring.io/guides/tutorials/rest/)
* [Accessing data with MySQL](https://spring.io/guides/gs/accessing-data-mysql/)
* [Accessing Data with JPA](https://spring.io/guides/gs/accessing-data-jpa/)
* [Using Spring Data JDBC](https://github.com/spring-projects/spring-data-examples/tree/main/jdbc/basics)

### Maven Parent overrides

Due to Maven's design, elements are inherited from the parent POM to the project POM.
While most of the inheritance is fine, it also inherits unwanted elements like `<license>` and `<developers>` from the parent.
To prevent this, the project POM contains empty overrides for these elements.
If you manually switch to a different parent and actually want the inheritance, you need to remove those overrides.

