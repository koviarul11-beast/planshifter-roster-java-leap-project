package com.example.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.time.LocalDateTime;

import com.example.demo.Model.Employee;
import com.example.demo.Model.Roster;
import com.example.demo.Model.Shift;
import com.example.demo.Model.SwapRequest;
import com.example.demo.Model.SwapStatus;
import com.example.demo.Service.ApiException;
import com.example.demo.Service.EmployeeService;
import com.example.demo.Service.RosterService;
import com.example.demo.Service.SwapService;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

@SpringBootTest
class DemoApplicationTests {
	@Autowired
	private EmployeeService employeeService;

	@Autowired
	private RosterService rosterService;

	@Autowired
	private SwapService swapService;

	@Test
	@Transactional
	void swapIsAppliedOnlyAfterColleagueAndManagerApproval() {
		Employee requester = employeeService.create("Ava", "ava@example.com", false);
		Employee colleague = employeeService.create("Noah", "noah@example.com", false);
		Employee manager = employeeService.create("Mina", "mina@example.com", true);
		Roster roster = rosterService.create(LocalDate.of(2026, 9, 28));
		Shift requesterShift = rosterService.addShift(roster.getId(), requester.getId(),
				LocalDateTime.of(2026, 9, 28, 9, 0), LocalDateTime.of(2026, 9, 28, 13, 0));
		Shift colleagueShift = rosterService.addShift(roster.getId(), colleague.getId(),
				LocalDateTime.of(2026, 9, 29, 9, 0), LocalDateTime.of(2026, 9, 29, 13, 0));

		SwapRequest request = swapService.create(requester.getId(), colleague.getId(),
				requesterShift.getId(), colleagueShift.getId());
		assertEquals(SwapStatus.PENDING_COLLEAGUE, request.getStatus());
		assertEquals(requester.getId(), requesterShift.getEmployee().getId());

		request = swapService.colleagueDecision(request.getId(), colleague.getId(), true);
		assertEquals(SwapStatus.PENDING_MANAGER, request.getStatus());
		assertEquals(requester.getId(), requesterShift.getEmployee().getId());

		request = swapService.managerDecision(request.getId(), manager.getId(), true);
		assertEquals(SwapStatus.APPROVED, request.getStatus());
		assertEquals(colleague.getId(), requesterShift.getEmployee().getId());
		assertEquals(requester.getId(), colleagueShift.getEmployee().getId());
	}

	@Test
	@Transactional
	void rejectsOverlappingShiftForEmployee() {
		Employee employee = employeeService.create("Ira", "ira@example.com", false);
		Roster roster = rosterService.create(LocalDate.of(2026, 9, 28));
		rosterService.addShift(roster.getId(), employee.getId(),
				LocalDateTime.of(2026, 9, 28, 9, 0), LocalDateTime.of(2026, 9, 28, 13, 0));

		assertThrows(ApiException.class, () -> rosterService.addShift(roster.getId(), employee.getId(),
				LocalDateTime.of(2026, 9, 28, 12, 0), LocalDateTime.of(2026, 9, 28, 16, 0)));
	}

	@Test
	@Transactional
	void updatesAndDeletesEmployeeWithoutReferences() {
		Employee employee = employeeService.create("Ava", "ava@example.com", false);

		employee = employeeService.update(employee.getId(), "Ava Patel", "ava@example.com", true);
		assertEquals("Ava Patel", employee.getName());
		assertEquals(true, employee.isManager());

		Long employeeId = employee.getId();
		employeeService.delete(employeeId);
		assertThrows(ApiException.class, () -> employeeService.findById(employeeId));
	}

	@Test
	@Transactional
	void updatesAndDeletesShiftWithoutSwapHistory() {
		Employee first = employeeService.create("Ava", "ava@example.com", false);
		Employee second = employeeService.create("Noah", "noah@example.com", false);
		Roster roster = rosterService.create(LocalDate.of(2026, 9, 28));
		Shift shift = rosterService.addShift(roster.getId(), first.getId(),
				LocalDateTime.of(2026, 9, 28, 9, 0), LocalDateTime.of(2026, 9, 28, 13, 0));

		shift = rosterService.updateShift(roster.getId(), shift.getId(), second.getId(),
				LocalDateTime.of(2026, 9, 28, 10, 0), LocalDateTime.of(2026, 9, 28, 14, 0));
		assertEquals(second.getId(), shift.getEmployee().getId());
		assertEquals(LocalDateTime.of(2026, 9, 28, 10, 0), shift.getStartsAt());

		rosterService.deleteShift(roster.getId(), shift.getId());
		assertEquals(0, rosterService.findById(roster.getId()).getShifts().size());
	}

	@Test
	@Transactional
	void editsAndDeletesSwapOnlyBeforeColleagueAcceptance() {
		Employee requester = employeeService.create("Ava", "ava@example.com", false);
		Employee colleague = employeeService.create("Noah", "noah@example.com", false);
		Roster roster = rosterService.create(LocalDate.of(2026, 9, 28));
		Shift firstRequesterShift = rosterService.addShift(roster.getId(), requester.getId(),
				LocalDateTime.of(2026, 9, 28, 9, 0), LocalDateTime.of(2026, 9, 28, 13, 0));
		Shift secondRequesterShift = rosterService.addShift(roster.getId(), requester.getId(),
				LocalDateTime.of(2026, 9, 29, 9, 0), LocalDateTime.of(2026, 9, 29, 13, 0));
		Shift colleagueShift = rosterService.addShift(roster.getId(), colleague.getId(),
				LocalDateTime.of(2026, 9, 30, 9, 0), LocalDateTime.of(2026, 9, 30, 13, 0));

		SwapRequest request = swapService.create(requester.getId(), colleague.getId(),
				firstRequesterShift.getId(), colleagueShift.getId());
		request = swapService.update(request.getId(), requester.getId(), colleague.getId(),
				secondRequesterShift.getId(), colleagueShift.getId());
		assertEquals(secondRequesterShift.getId(), request.getRequestedShift().getId());

		swapService.delete(request.getId());
		Long deletedRequestId = request.getId();
		assertThrows(ApiException.class, () -> swapService.findById(deletedRequestId));

		SwapRequest acceptedRequest = swapService.create(requester.getId(), colleague.getId(),
				firstRequesterShift.getId(), colleagueShift.getId());
		swapService.colleagueDecision(acceptedRequest.getId(), colleague.getId(), true);
		Long acceptedRequestId = acceptedRequest.getId();
		assertThrows(ApiException.class, () -> swapService.update(acceptedRequestId, requester.getId(),
				colleague.getId(), firstRequesterShift.getId(), colleagueShift.getId()));
		assertThrows(ApiException.class, () -> swapService.delete(acceptedRequestId));
	}

	@Test
	@Transactional
	void rechecksOverlapBeforeManagerAppliesSwap() {
		Employee requester = employeeService.create("Kai", "kai@example.com", false);
		Employee colleague = employeeService.create("Lee", "lee@example.com", false);
		Employee manager = employeeService.create("Sam", "sam@example.com", true);
		Roster roster = rosterService.create(LocalDate.of(2026, 9, 28));
		Shift requesterShift = rosterService.addShift(roster.getId(), requester.getId(),
				LocalDateTime.of(2026, 9, 28, 9, 0), LocalDateTime.of(2026, 9, 28, 13, 0));
		Shift colleagueShift = rosterService.addShift(roster.getId(), colleague.getId(),
				LocalDateTime.of(2026, 9, 29, 9, 0), LocalDateTime.of(2026, 9, 29, 13, 0));
		SwapRequest request = swapService.create(requester.getId(), colleague.getId(),
				requesterShift.getId(), colleagueShift.getId());
		swapService.colleagueDecision(request.getId(), colleague.getId(), true);

		rosterService.addShift(roster.getId(), requester.getId(),
				LocalDateTime.of(2026, 9, 29, 10, 0), LocalDateTime.of(2026, 9, 29, 11, 0));
		assertThrows(ApiException.class,
				() -> swapService.managerDecision(request.getId(), manager.getId(), true));
		assertEquals(requester.getId(), requesterShift.getEmployee().getId());
		assertEquals(colleague.getId(), colleagueShift.getEmployee().getId());
		assertEquals(SwapStatus.PENDING_MANAGER, request.getStatus());
	}

}
