package com.example.demo.Model;

public enum SwapStatus {
    PENDING_COLLEAGUE,
    PENDING_MANAGER,
    APPROVED,
    DECLINED
}