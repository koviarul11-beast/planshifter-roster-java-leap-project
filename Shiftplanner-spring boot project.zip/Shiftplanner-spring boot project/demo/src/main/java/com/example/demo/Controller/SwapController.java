package com.example.demo.Controller;

import java.util.List;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;

import com.example.demo.Model.SwapRequest;
import com.example.demo.Service.SwapService;

@RestController
@RequestMapping("/api/swaps")
@Tag(name = "Shift swaps", description = "Propose exchanges and move them through colleague and manager approval.")
public class SwapController {
    private final SwapService swaps;

    public SwapController(SwapService swaps) {
        this.swaps = swaps;
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
        @Operation(summary = "Request a shift swap", description = "The requester and colleague must own the selected shifts, and both shifts must belong to the same roster.")
        @ApiResponses({
            @ApiResponse(responseCode = "201", description = "Swap request created with PENDING_COLLEAGUE status."),
            @ApiResponse(responseCode = "400", description = "The employees or shifts cannot be exchanged.", content = @Content(schema = @Schema(implementation = ApiExceptionHandler.ApiError.class))),
            @ApiResponse(responseCode = "404", description = "An employee or shift was not found.", content = @Content(schema = @Schema(implementation = ApiExceptionHandler.ApiError.class))),
            @ApiResponse(responseCode = "409", description = "A proposed assignment overlaps another shift.", content = @Content(schema = @Schema(implementation = ApiExceptionHandler.ApiError.class)))
        })
    public SwapRequest create(@Valid @RequestBody CreateSwapRequest body) {
        return swaps.create(body.requesterId(), body.colleagueId(), body.requestedShiftId(), body.offeredShiftId());
    }

    @PutMapping("/{id}")
    @Operation(summary = "Update a pending swap request", description = "Only requests awaiting colleague acceptance can be changed.")
    public SwapRequest update(@Parameter(description = "Swap request database ID.", example = "1") @PathVariable Long id,
            @Valid @RequestBody CreateSwapRequest body) {
        return swaps.update(id, body.requesterId(), body.colleagueId(), body.requestedShiftId(), body.offeredShiftId());
    }

    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    @Operation(summary = "Delete a pending swap request", description = "Only requests awaiting colleague acceptance can be deleted.")
    public void delete(@Parameter(description = "Swap request database ID.", example = "1") @PathVariable Long id) {
        swaps.delete(id);
    }

    @PutMapping("/{id}/colleague-decision")
    @Operation(summary = "Respond to a swap as the colleague", description = "The invited colleague can accept or decline a pending request. Acceptance sends it to manager approval.")
    @ApiResponses({
            @ApiResponse(responseCode = "200", description = "Colleague decision recorded."),
            @ApiResponse(responseCode = "400", description = "Decision is invalid for a colleague.", content = @Content(schema = @Schema(implementation = ApiExceptionHandler.ApiError.class))),
            @ApiResponse(responseCode = "403", description = "The actor is not the invited colleague.", content = @Content(schema = @Schema(implementation = ApiExceptionHandler.ApiError.class))),
            @ApiResponse(responseCode = "404", description = "The swap request was not found.", content = @Content(schema = @Schema(implementation = ApiExceptionHandler.ApiError.class))),
            @ApiResponse(responseCode = "409", description = "The swap is not awaiting the colleague or assignments now conflict.", content = @Content(schema = @Schema(implementation = ApiExceptionHandler.ApiError.class)))
    })
    public SwapRequest colleagueDecision(@Parameter(description = "Swap request database ID.", example = "1") @PathVariable Long id,
            @Valid @RequestBody ColleagueDecisionRequest body) {
        return swaps.colleagueDecision(id, body.actorId(), body.decision() == ColleagueDecision.ACCEPT);
    }

    @PutMapping("/{id}/manager-decision")
    @Operation(summary = "Make the final swap decision", description = "A manager can approve or decline a request after the colleague accepts it. Approval changes shift ownership.")
    @ApiResponses({
            @ApiResponse(responseCode = "200", description = "Manager decision recorded."),
            @ApiResponse(responseCode = "400", description = "Decision is invalid for a manager.", content = @Content(schema = @Schema(implementation = ApiExceptionHandler.ApiError.class))),
            @ApiResponse(responseCode = "403", description = "The actor is not a manager.", content = @Content(schema = @Schema(implementation = ApiExceptionHandler.ApiError.class))),
            @ApiResponse(responseCode = "404", description = "The manager or swap request was not found.", content = @Content(schema = @Schema(implementation = ApiExceptionHandler.ApiError.class))),
            @ApiResponse(responseCode = "409", description = "The swap is not awaiting a manager or assignments now conflict.", content = @Content(schema = @Schema(implementation = ApiExceptionHandler.ApiError.class)))
    })
    public SwapRequest managerDecision(@Parameter(description = "Swap request database ID.", example = "1") @PathVariable Long id,
            @Valid @RequestBody ManagerDecisionRequest body) {
        return swaps.managerDecision(id, body.actorId(), body.decision() == ManagerDecision.APPROVE);
    }

    @GetMapping
    @Operation(summary = "List swaps for an employee", description = "Returns requests where the employee is either requester or invited colleague.")
    @ApiResponse(responseCode = "404", description = "The employee was not found.", content = @Content(schema = @Schema(implementation = ApiExceptionHandler.ApiError.class)))
    public List<SwapRequest> findForEmployee(@RequestParam Long employeeId) {
        return swaps.findForEmployee(employeeId);
    }

    @GetMapping("/{id}")
    @Operation(summary = "Get a swap request", description = "Returns a swap request, its participants, the two shifts, and its current status.")
    @ApiResponse(responseCode = "404", description = "The swap request was not found.", content = @Content(schema = @Schema(implementation = ApiExceptionHandler.ApiError.class)))
    public SwapRequest findById(@Parameter(description = "Swap request database ID.", example = "1") @PathVariable Long id) {
        return swaps.findById(id);
    }

    @Schema(name = "CreateSwapRequest", description = "IDs for the two employees and the shifts they propose to exchange.")
    public record CreateSwapRequest(@NotNull Long requesterId, @NotNull Long colleagueId,
            @NotNull Long requestedShiftId, @NotNull Long offeredShiftId) {}

    @Schema(name = "ColleagueDecisionRequest", description = "Decision submitted by the invited colleague.")
    public record ColleagueDecisionRequest(@NotNull @Schema(example = "2") Long actorId,
            @NotNull ColleagueDecision decision) {}

    @Schema(description = "Allowed decisions for an invited colleague.")
    public enum ColleagueDecision {
        ACCEPT,
        DECLINE
    }

    @Schema(name = "ManagerDecisionRequest", description = "Final decision submitted by a manager.")
    public record ManagerDecisionRequest(@NotNull @Schema(example = "3") Long actorId,
            @NotNull ManagerDecision decision) {}

    @Schema(description = "Allowed final decisions for a manager.")
    public enum ManagerDecision {
        APPROVE,
        DECLINE
    }
}