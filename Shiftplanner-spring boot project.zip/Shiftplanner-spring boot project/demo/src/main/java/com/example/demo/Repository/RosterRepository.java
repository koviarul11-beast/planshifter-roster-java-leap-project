package com.example.demo.Repository;

import java.time.LocalDate;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.demo.Model.Roster;

public interface RosterRepository extends JpaRepository<Roster, Long> {
    Optional<Roster> findByWeekStartDate(LocalDate weekStartDate);
}