package com.example.demo.Controller;

import java.util.List;

import jakarta.validation.Valid;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;

import com.example.demo.Model.Employee;
import com.example.demo.Service.EmployeeService;

@RestController
@RequestMapping("/api/employees")
@Tag(name = "Employees", description = "Create and look up employees in the shift planner.")
public class EmployeeController {
    private final EmployeeService employees;

    public EmployeeController(EmployeeService employees) {
        this.employees = employees;
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
        @Operation(summary = "Create an employee", description = "Email addresses must be unique. Set manager to true for a manager who can approve swaps.")
        @ApiResponses({
            @ApiResponse(responseCode = "201", description = "Employee created."),
            @ApiResponse(responseCode = "400", description = "Name or email is invalid.", content = @Content(schema = @Schema(implementation = ApiExceptionHandler.ApiError.class))),
            @ApiResponse(responseCode = "409", description = "The email address is already in use.", content = @Content(schema = @Schema(implementation = ApiExceptionHandler.ApiError.class)))
        })
    public Employee create(@Valid @RequestBody CreateEmployeeRequest body) {
        return employees.create(body.name(), body.email(), body.manager());
    }

    @PutMapping("/{id}")
    @Operation(summary = "Update an employee", description = "Replaces an employee's name, email, and manager status.")
    @ApiResponses({
        @ApiResponse(responseCode = "200", description = "Employee updated."),
        @ApiResponse(responseCode = "404", description = "No employee exists with this ID.", content = @Content(schema = @Schema(implementation = ApiExceptionHandler.ApiError.class))),
        @ApiResponse(responseCode = "409", description = "The email is already in use.", content = @Content(schema = @Schema(implementation = ApiExceptionHandler.ApiError.class)))
    })
    public Employee update(@Parameter(description = "Employee database ID.", example = "1") @PathVariable Long id,
            @Valid @RequestBody CreateEmployeeRequest body) {
        return employees.update(id, body.name(), body.email(), body.manager());
    }

    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    @Operation(summary = "Delete an employee", description = "Employees referenced by shifts or swap history cannot be deleted.")
    @ApiResponses({
        @ApiResponse(responseCode = "204", description = "Employee deleted."),
        @ApiResponse(responseCode = "404", description = "No employee exists with this ID.", content = @Content(schema = @Schema(implementation = ApiExceptionHandler.ApiError.class))),
        @ApiResponse(responseCode = "409", description = "The employee is referenced by shifts or swap history.", content = @Content(schema = @Schema(implementation = ApiExceptionHandler.ApiError.class)))
    })
    public void delete(@Parameter(description = "Employee database ID.", example = "1") @PathVariable Long id) {
        employees.delete(id);
    }

    @GetMapping
    @Operation(summary = "List employees", description = "Returns every employee, including manager flags.")
    public List<Employee> findAll() {
        return employees.findAll();
    }

    @GetMapping("/{id}")
    @Operation(summary = "Get an employee", description = "Returns one employee by its database ID.")
    @ApiResponse(responseCode = "404", description = "No employee exists with this ID.", content = @Content(schema = @Schema(implementation = ApiExceptionHandler.ApiError.class)))
    public Employee findById(@Parameter(description = "Employee database ID.", example = "1") @PathVariable Long id) {
        return employees.findById(id);
    }

    @Schema(name = "CreateEmployeeRequest", description = "Employee details to add to the directory.")
    public record CreateEmployeeRequest(
            @NotBlank @Schema(description = "Employee's display name.", example = "Ava Patel") String name,
            @NotBlank @Email @Schema(description = "Unique contact email address.", format = "email", example = "ava@example.com") String email,
            @Schema(description = "Whether this employee can approve swaps.", example = "false") boolean manager) {}
}