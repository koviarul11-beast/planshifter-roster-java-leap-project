package com.example.demo.Service;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.example.demo.Model.Employee;
import com.example.demo.Model.Shift;
import com.example.demo.Model.SwapRequest;
import com.example.demo.Model.SwapStatus;
import com.example.demo.Repository.EmployeeRepository;
import com.example.demo.Repository.ShiftRepository;
import com.example.demo.Repository.SwapRequestRepository;

@Service
@Transactional
public class SwapService {
    private final EmployeeRepository employees;
    private final ShiftRepository shifts;
    private final SwapRequestRepository requests;
    private final RosterService rosterService;

    public SwapService(EmployeeRepository employees, ShiftRepository shifts,
            SwapRequestRepository requests, RosterService rosterService) {
        this.employees = employees;
        this.shifts = shifts;
        this.requests = requests;
        this.rosterService = rosterService;
    }

    public SwapRequest create(Long requesterId, Long colleagueId, Long requestedShiftId, Long offeredShiftId) {
        SwapRequest request = new SwapRequest();
        updateDetails(request, requesterId, colleagueId, requestedShiftId, offeredShiftId);
        return requests.save(request);
    }

    public SwapRequest update(Long requestId, Long requesterId, Long colleagueId,
            Long requestedShiftId, Long offeredShiftId) {
        SwapRequest request = request(requestId);
        requireStatus(request, SwapStatus.PENDING_COLLEAGUE);
        updateDetails(request, requesterId, colleagueId, requestedShiftId, offeredShiftId);
        return requests.save(request);
    }

    public void delete(Long requestId) {
        SwapRequest request = request(requestId);
        requireStatus(request, SwapStatus.PENDING_COLLEAGUE);
        requests.delete(request);
    }

    private void updateDetails(SwapRequest request, Long requesterId, Long colleagueId,
            Long requestedShiftId, Long offeredShiftId) {
        if (requesterId.equals(colleagueId)) {
            throw new ApiException(HttpStatus.BAD_REQUEST, "A swap must involve two different employees.");
        }
        Employee requester = employee(requesterId);
        Employee colleague = employee(colleagueId);
        Shift requestedShift = shift(requestedShiftId);
        Shift offeredShift = shift(offeredShiftId);
        if (requestedShiftId.equals(offeredShiftId)) {
            throw new ApiException(HttpStatus.BAD_REQUEST, "Choose two different shifts to exchange.");
        }
        if (!requestedShift.getEmployee().getId().equals(requesterId)
                || !offeredShift.getEmployee().getId().equals(colleagueId)) {
            throw new ApiException(HttpStatus.BAD_REQUEST, "Each employee must own the shift they are exchanging.");
        }
        if (!requestedShift.getRoster().getId().equals(offeredShift.getRoster().getId())) {
            throw new ApiException(HttpStatus.BAD_REQUEST, "Both shifts must belong to the same weekly roster.");
        }
        validateProposedAssignments(requester, colleague, requestedShift, offeredShift);
        request.setRequester(requester);
        request.setColleague(colleague);
        request.setRequestedShift(requestedShift);
        request.setOfferedShift(offeredShift);
    }

    public SwapRequest colleagueDecision(Long requestId, Long colleagueId, boolean accept) {
        SwapRequest request = request(requestId);
        if (!request.getColleague().getId().equals(colleagueId)) {
            throw new ApiException(HttpStatus.FORBIDDEN, "Only the invited colleague can respond to this request.");
        }
        requireStatus(request, SwapStatus.PENDING_COLLEAGUE);
        if (!accept) {
            request.setStatus(SwapStatus.DECLINED);
        } else {
            validateProposedAssignments(request.getRequester(), request.getColleague(),
                    request.getRequestedShift(), request.getOfferedShift());
            request.setStatus(SwapStatus.PENDING_MANAGER);
        }
        return requests.save(request);
    }

    public SwapRequest managerDecision(Long requestId, Long managerId, boolean approve) {
        Employee manager = employee(managerId);
        if (!manager.isManager()) {
            throw new ApiException(HttpStatus.FORBIDDEN, "Only a manager can give final approval.");
        }
        SwapRequest request = request(requestId);
        requireStatus(request, SwapStatus.PENDING_MANAGER);
        if (!approve) {
            request.setStatus(SwapStatus.DECLINED);
            return requests.save(request);
        }

        Shift requestedShift = request.getRequestedShift();
        Shift offeredShift = request.getOfferedShift();
        validateProposedAssignments(request.getRequester(), request.getColleague(), requestedShift, offeredShift);
        requestedShift.setEmployee(request.getColleague());
        offeredShift.setEmployee(request.getRequester());
        shifts.saveAll(List.of(requestedShift, offeredShift));
        request.setStatus(SwapStatus.APPROVED);
        return requests.save(request);
    }

    @Transactional(readOnly = true)
    public List<SwapRequest> findForEmployee(Long employeeId) {
        employee(employeeId);
        return requests.findByRequesterIdOrColleagueId(employeeId, employeeId);
    }

    @Transactional(readOnly = true)
    public SwapRequest findById(Long id) {
        return request(id);
    }

    private void validateProposedAssignments(Employee requester, Employee colleague,
            Shift requestedShift, Shift offeredShift) {
        List<Long> changingShifts = List.of(requestedShift.getId(), offeredShift.getId());
        rosterService.assertNoOverlap(requester, offeredShift, changingShifts);
        rosterService.assertNoOverlap(colleague, requestedShift, changingShifts);
    }

    private Employee employee(Long id) {
        return employees.findById(id)
                .orElseThrow(() -> new ApiException(HttpStatus.NOT_FOUND, "Employee " + id + " was not found."));
    }

    private Shift shift(Long id) {
        return shifts.findById(id)
                .orElseThrow(() -> new ApiException(HttpStatus.NOT_FOUND, "Shift " + id + " was not found."));
    }

    private SwapRequest request(Long id) {
        return requests.findById(id)
                .orElseThrow(() -> new ApiException(HttpStatus.NOT_FOUND, "Swap request " + id + " was not found."));
    }

    private void requireStatus(SwapRequest request, SwapStatus expected) {
        if (request.getStatus() != expected) {
            throw new ApiException(HttpStatus.CONFLICT,
                    "This request is " + request.getStatus() + " and cannot be changed at this step.");
        }
    }
}