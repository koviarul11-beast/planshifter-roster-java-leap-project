package com.example.demo;

import org.springframework.context.annotation.Configuration;

import io.swagger.v3.oas.annotations.OpenAPIDefinition;
import io.swagger.v3.oas.annotations.info.Info;

@Configuration
@OpenAPIDefinition(info = @Info(
        title = "Shift Planner API",
        version = "1.0.0",
        description = "Manage employees, weekly rosters, shifts, and the colleague/manager swap approval workflow."))
public class OpenApiConfiguration {
}