package com.example.demo.Service;

import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.example.demo.Model.Employee;
import com.example.demo.Model.Roster;
import com.example.demo.Model.Shift;
import com.example.demo.Repository.EmployeeRepository;
import com.example.demo.Repository.RosterRepository;
import com.example.demo.Repository.ShiftRepository;
import com.example.demo.Repository.SwapRequestRepository;

@Service
@Transactional
public class RosterService {
    private final EmployeeRepository employees;
    private final RosterRepository rosters;
    private final ShiftRepository shifts;
    private final SwapRequestRepository swapRequests;

    public RosterService(EmployeeRepository employees, RosterRepository rosters, ShiftRepository shifts,
            SwapRequestRepository swapRequests) {
        this.employees = employees;
        this.rosters = rosters;
        this.shifts = shifts;
        this.swapRequests = swapRequests;
    }

    public Roster create(LocalDate weekStartDate) {
        validateWeekStart(weekStartDate);
        ensureWeekAvailable(weekStartDate, null);
        Roster roster = new Roster();
        roster.setWeekStartDate(weekStartDate);
        return rosters.save(roster);
    }

    public Roster update(Long id, LocalDate weekStartDate) {
        validateWeekStart(weekStartDate);
        Roster roster = findById(id);
        ensureWeekAvailable(weekStartDate, id);
        if (roster.getShifts().stream().anyMatch(shift -> {
            LocalDate shiftDate = shift.getStartsAt().toLocalDate();
            return shiftDate.isBefore(weekStartDate) || !shiftDate.isBefore(weekStartDate.plusDays(7));
        })) {
            throw new ApiException(HttpStatus.BAD_REQUEST,
                    "The updated roster week must contain all of its existing shifts.");
        }
        roster.setWeekStartDate(weekStartDate);
        return rosters.save(roster);
    }

    public void delete(Long id) {
        Roster roster = findById(id);
        boolean hasSwapHistory = roster.getShifts().stream()
                .anyMatch(shift -> swapRequests.existsByRequestedShiftIdOrOfferedShiftId(shift.getId(), shift.getId()));
        if (hasSwapHistory) {
            throw new ApiException(HttpStatus.CONFLICT,
                    "This roster contains shifts referenced by swap history and cannot be deleted.");
        }
        rosters.delete(roster);
    }

    @Transactional(readOnly = true)
    public List<Roster> findAll() {
        return rosters.findAll();
    }

    @Transactional(readOnly = true)
    public Roster findById(Long id) {
        return rosters.findById(id)
                .orElseThrow(() -> new ApiException(HttpStatus.NOT_FOUND, "Roster " + id + " was not found."));
    }

    public Shift addShift(Long rosterId, Long employeeId, LocalDateTime startsAt, LocalDateTime endsAt) {
        validateShiftTimes(startsAt, endsAt);
        Roster roster = findById(rosterId);
        LocalDate shiftDate = startsAt.toLocalDate();
        if (shiftDate.isBefore(roster.getWeekStartDate())
                || !shiftDate.isBefore(roster.getWeekStartDate().plusDays(7))) {
            throw new ApiException(HttpStatus.BAD_REQUEST, "The shift must start within the roster week.");
        }
        Employee employee = employees.findById(employeeId)
                .orElseThrow(() -> new ApiException(HttpStatus.NOT_FOUND, "Employee " + employeeId + " was not found."));
        Shift shift = new Shift();
        shift.setEmployee(employee);
        shift.setStartsAt(startsAt);
        shift.setEndsAt(endsAt);
        assertNoOverlap(employee, shift, List.of());
        roster.addShift(shift);
        return shifts.save(shift);
    }

    public Shift updateShift(Long rosterId, Long shiftId, Long employeeId,
            LocalDateTime startsAt, LocalDateTime endsAt) {
        validateShiftTimes(startsAt, endsAt);
        Roster roster = findById(rosterId);
        Shift shift = shifts.findById(shiftId)
                .filter(existing -> existing.getRoster().getId().equals(rosterId))
                .orElseThrow(() -> new ApiException(HttpStatus.NOT_FOUND, "Shift " + shiftId + " was not found."));
        ensureShiftNotInSwapHistory(shiftId);
        validateShiftDate(roster, startsAt);
        Employee employee = employees.findById(employeeId)
                .orElseThrow(() -> new ApiException(HttpStatus.NOT_FOUND, "Employee " + employeeId + " was not found."));
        shift.setEmployee(employee);
        shift.setStartsAt(startsAt);
        shift.setEndsAt(endsAt);
        assertNoOverlap(employee, shift, List.of(shiftId));
        return shifts.save(shift);
    }

    public void deleteShift(Long rosterId, Long shiftId) {
        Roster roster = findById(rosterId);
        Shift shift = shifts.findById(shiftId)
                .filter(existing -> existing.getRoster().getId().equals(rosterId))
                .orElseThrow(() -> new ApiException(HttpStatus.NOT_FOUND, "Shift " + shiftId + " was not found."));
        ensureShiftNotInSwapHistory(shiftId);
        roster.getShifts().remove(shift);
        shifts.delete(shift);
    }

    private void ensureShiftNotInSwapHistory(Long shiftId) {
        if (swapRequests.existsByRequestedShiftIdOrOfferedShiftId(shiftId, shiftId)) {
            throw new ApiException(HttpStatus.CONFLICT,
                    "This shift is referenced by swap history and cannot be changed or deleted.");
        }
    }

    private void validateWeekStart(LocalDate weekStartDate) {
        if (weekStartDate == null || weekStartDate.getDayOfWeek() != DayOfWeek.MONDAY) {
            throw new ApiException(HttpStatus.BAD_REQUEST, "The roster week must start on a Monday.");
        }
    }

    private void ensureWeekAvailable(LocalDate weekStartDate, Long currentRosterId) {
        rosters.findByWeekStartDate(weekStartDate).ifPresent(existing -> {
            if (currentRosterId == null || !existing.getId().equals(currentRosterId)) {
                throw new ApiException(HttpStatus.CONFLICT, "A roster already exists for this week.");
            }
        });
    }

    private void validateShiftDate(Roster roster, LocalDateTime startsAt) {
        LocalDate shiftDate = startsAt.toLocalDate();
        if (shiftDate.isBefore(roster.getWeekStartDate())
                || !shiftDate.isBefore(roster.getWeekStartDate().plusDays(7))) {
            throw new ApiException(HttpStatus.BAD_REQUEST, "The shift must start within the roster week.");
        }
    }

    static void validateShiftTimes(LocalDateTime startsAt, LocalDateTime endsAt) {
        if (startsAt == null || endsAt == null || !endsAt.isAfter(startsAt)) {
            throw new ApiException(HttpStatus.BAD_REQUEST, "Shift end time must be after its start time.");
        }
    }

    void assertNoOverlap(Employee employee, Shift candidate, List<Long> excludedShiftIds) {
        for (Shift existing : shifts.findByEmployeeId(employee.getId())) {
            if (!excludedShiftIds.contains(existing.getId())
                    && existing.getStartsAt().isBefore(candidate.getEndsAt())
                    && candidate.getStartsAt().isBefore(existing.getEndsAt())) {
                throw new ApiException(HttpStatus.CONFLICT,
                        "Employee " + employee.getId() + " already has an overlapping shift.");
            }
        }
    }
}