package com.example.demo.Repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.demo.Model.SwapRequest;

public interface SwapRequestRepository extends JpaRepository<SwapRequest, Long> {
    List<SwapRequest> findByRequesterIdOrColleagueId(Long requesterId, Long colleagueId);
    boolean existsByRequesterIdOrColleagueId(Long requesterId, Long colleagueId);
    boolean existsByRequestedShiftIdOrOfferedShiftId(Long requestedShiftId, Long offeredShiftId);
}