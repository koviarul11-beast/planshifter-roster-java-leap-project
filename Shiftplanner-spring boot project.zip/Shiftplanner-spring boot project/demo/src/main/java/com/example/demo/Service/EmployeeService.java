package com.example.demo.Service;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.example.demo.Model.Employee;
import com.example.demo.Repository.EmployeeRepository;
import com.example.demo.Repository.ShiftRepository;
import com.example.demo.Repository.SwapRequestRepository;

@Service
@Transactional
public class EmployeeService {
    private final EmployeeRepository employees;
    private final ShiftRepository shifts;
    private final SwapRequestRepository swapRequests;

    public EmployeeService(EmployeeRepository employees, ShiftRepository shifts, SwapRequestRepository swapRequests) {
        this.employees = employees;
        this.shifts = shifts;
        this.swapRequests = swapRequests;
    }

    public Employee create(String name, String email, boolean manager) {
        Employee employee = new Employee();
        updateDetails(employee, name, email, manager);
        return employees.save(employee);
    }

    public Employee update(Long id, String name, String email, boolean manager) {
        Employee employee = findById(id);
        updateDetails(employee, name, email, manager);
        return employees.save(employee);
    }

    public void delete(Long id) {
        Employee employee = findById(id);
        if (!shifts.findByEmployeeId(id).isEmpty() || swapRequests.existsByRequesterIdOrColleagueId(id, id)) {
            throw new ApiException(HttpStatus.CONFLICT,
                    "This employee is referenced by shifts or swap history and cannot be deleted.");
        }
        employees.delete(employee);
    }

    private void updateDetails(Employee employee, String name, String email, boolean manager) {
        employees.findByEmailIgnoreCase(email.trim()).ifPresent(existing -> {
            if (employee.getId() == null || !existing.getId().equals(employee.getId())) {
                throw new ApiException(HttpStatus.CONFLICT, "An employee with this email already exists.");
            }
        });
        employee.setName(name.trim());
        employee.setEmail(email.trim().toLowerCase());
        employee.setManager(manager);
    }

    @Transactional(readOnly = true)
    public List<Employee> findAll() {
        return employees.findAll();
    }

    @Transactional(readOnly = true)
    public Employee findById(Long id) {
        return employees.findById(id)
                .orElseThrow(() -> new ApiException(HttpStatus.NOT_FOUND, "Employee " + id + " was not found."));
    }
}