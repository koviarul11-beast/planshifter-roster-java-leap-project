package com.example.demo.Controller;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;

import com.example.demo.Model.Roster;
import com.example.demo.Model.Shift;
import com.example.demo.Service.RosterService;

@RestController
@RequestMapping("/api/rosters")
@Tag(name = "Rosters and shifts", description = "Create weekly rosters and assign employees to shifts.")
public class RosterController {
    private final RosterService rosters;

    public RosterController(RosterService rosters) {
        this.rosters = rosters;
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
        @Operation(summary = "Create a weekly roster", description = "The week start date must be a Monday. Only one roster can exist for each week.")
        @ApiResponses({
            @ApiResponse(responseCode = "201", description = "Roster created."),
            @ApiResponse(responseCode = "400", description = "The request is missing a valid week start date.", content = @Content(schema = @Schema(implementation = ApiExceptionHandler.ApiError.class))),
            @ApiResponse(responseCode = "409", description = "A roster already exists for that week.", content = @Content(schema = @Schema(implementation = ApiExceptionHandler.ApiError.class)))
        })
    public Roster create(@Valid @RequestBody CreateRosterRequest body) {
        return rosters.create(body.weekStartDate());
    }

    @PutMapping("/{id}")
    @Operation(summary = "Update a weekly roster", description = "Changes the week start date if it is a Monday, unused, and contains all existing shifts.")
    public Roster update(@Parameter(description = "Roster database ID.", example = "1") @PathVariable Long id,
            @Valid @RequestBody CreateRosterRequest body) {
        return rosters.update(id, body.weekStartDate());
    }

    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    @Operation(summary = "Delete a weekly roster", description = "Deletes its shifts unless any shift is referenced by swap history.")
    public void delete(@Parameter(description = "Roster database ID.", example = "1") @PathVariable Long id) {
        rosters.delete(id);
    }

    @GetMapping
    @Operation(summary = "List weekly rosters", description = "Returns rosters with their scheduled shifts.")
    public List<Roster> findAll() {
        return rosters.findAll();
    }

    @GetMapping("/{id}")
        @Operation(summary = "Get a weekly roster", description = "Returns one roster and its scheduled shifts.")
        @ApiResponse(responseCode = "404", description = "No roster exists with this ID.", content = @Content(schema = @Schema(implementation = ApiExceptionHandler.ApiError.class)))
        public Roster findById(@Parameter(description = "Roster database ID.", example = "1") @PathVariable Long id) {
        return rosters.findById(id);
    }

    @PostMapping("/{rosterId}/shifts")
    @ResponseStatus(HttpStatus.CREATED)
        @Operation(summary = "Assign a shift", description = "Adds a shift to the roster. The employee must not already have an overlapping shift.")
        @ApiResponses({
            @ApiResponse(responseCode = "201", description = "Shift created."),
            @ApiResponse(responseCode = "400", description = "The shift dates or times are invalid.", content = @Content(schema = @Schema(implementation = ApiExceptionHandler.ApiError.class))),
            @ApiResponse(responseCode = "404", description = "The roster or employee was not found.", content = @Content(schema = @Schema(implementation = ApiExceptionHandler.ApiError.class))),
            @ApiResponse(responseCode = "409", description = "The shift overlaps another assignment.", content = @Content(schema = @Schema(implementation = ApiExceptionHandler.ApiError.class)))
        })
        public Shift addShift(@Parameter(description = "Roster database ID.", example = "1") @PathVariable Long rosterId,
            @Valid @RequestBody CreateShiftRequest body) {
        return rosters.addShift(rosterId, body.employeeId(), body.startsAt(), body.endsAt());
    }

        @PutMapping("/{rosterId}/shifts/{shiftId}")
        @Operation(summary = "Update a shift", description = "Changes the employee and times after validating the roster week and overlapping assignments.")
        public Shift updateShift(@Parameter(description = "Roster database ID.", example = "1") @PathVariable Long rosterId,
                @Parameter(description = "Shift database ID.", example = "1") @PathVariable Long shiftId,
                @Valid @RequestBody CreateShiftRequest body) {
            return rosters.updateShift(rosterId, shiftId, body.employeeId(), body.startsAt(), body.endsAt());
        }

        @DeleteMapping("/{rosterId}/shifts/{shiftId}")
        @ResponseStatus(HttpStatus.NO_CONTENT)
        @Operation(summary = "Delete a shift", description = "Shifts referenced by swap history cannot be deleted.")
        public void deleteShift(@Parameter(description = "Roster database ID.", example = "1") @PathVariable Long rosterId,
                @Parameter(description = "Shift database ID.", example = "1") @PathVariable Long shiftId) {
            rosters.deleteShift(rosterId, shiftId);
        }

        @Schema(name = "CreateRosterRequest", description = "The Monday date that starts the roster week.")
        public record CreateRosterRequest(
            @NotNull @Schema(description = "Roster week start date; must be a Monday.", example = "2026-09-28") LocalDate weekStartDate) {}

        @Schema(name = "CreateShiftRequest", description = "Employee and local start/end times for a new shift.")
    public record CreateShiftRequest(@NotNull Long employeeId,
            @NotNull @Schema(description = "Shift start in local date-time format.", example = "2026-09-28T09:00:00") LocalDateTime startsAt,
            @NotNull @Schema(description = "Shift end in local date-time format.", example = "2026-09-28T17:00:00") LocalDateTime endsAt) {}
}